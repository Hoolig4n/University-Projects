/* Charles Roberts
 * 140-001
 * Program 3
 * 3-26-2012
 * Program tracks a stock over the course of a week.
 */
package program3;

import java.util.HashSet;
import java.util.Set;
import java.util.Scanner;
/** 
 *
 * @author Charles
 */
public class Program3 {
    //Declare Variables
    static final String NAME1 = "Cougar";
    //static final String SYMBOL1 = "SIUE";
    
    public static void main(String[] args) {
        //Declare Scanner 
        Scanner keyboard = new Scanner(System.in);
        
        //Declare Stock Name
        Stock Name1 = new Stock();
        Name1.setName(NAME1);
        
        //Set Characteristics
        Name1.setPreviousStock(100.00);
        Name1.setName("Cougar");
        Name1.setName("SIUE");
    
         //Display Welcome Message, Monday
        System.out.println("Welcome to the Weekly Stock Tracker! ");    
        System.out.println("We are Tracking the Value of " + Name1.getName()+ "(" + Name1.getSymbol() + ") Stock.");
        System.out.println("");
        System.out.printf("Monday       : Opening Price: $ %.2f\n",Name1.getPreviousStock());
        System.out.print("Enter the Price at the end of the Day: ");  
        Name1.setCurrentStock(keyboard.nextDouble());
        System.out.printf("Percent Change for the Day: %.2f%%\n", Name1.calculate());
        System.out.println("");
        
        //Set current stock price into previous variable
        Name1.setPreviousStock(Name1.getCurrentStock());
        
        //Display Tuesday
        System.out.printf("Tuesday      : Opening Price: $ %.2f\n",Name1.getPreviousStock());
        System.out.print("Enter the Price at the end of the Day: ");
        Name1.setCurrentStock(keyboard.nextDouble());
        System.out.printf("Percent Change for the Day: %.2f%%\n", Name1.calculate());
        System.out.println("");
        
        //Set current stock price into previous variable
        Name1.setPreviousStock(Name1.getCurrentStock());
        
        //Display Wednesday
        System.out.printf("Wednesday    : Opening Price: $ %.2f\n",Name1.getPreviousStock());
        System.out.print("Enter the Price at the end of the Day: ");
        Name1.setCurrentStock(keyboard.nextDouble());
        System.out.printf("Percent Change for the Day: %.2f%%\n", Name1.calculate());
        System.out.println("");
        
        //Set current stock price into previous variable
        Name1.setPreviousStock(Name1.getCurrentStock());
        
        //Display Thursday
        System.out.printf("Thursday     : Opening Price: $ %.2f\n",Name1.getPreviousStock());
        System.out.print("Enter the Price at the end of the Day: ");
        Name1.setCurrentStock(keyboard.nextDouble());
        System.out.printf("Percent Change for the Day: %.2f%%\n", Name1.calculate());
        System.out.println("");
        
        //Set current stock price into previous variable
        Name1.setPreviousStock(Name1.getCurrentStock());
        
        //Display Friday
        System.out.printf("Friday       : Opening Price: $ %.2f\n",Name1.getPreviousStock());
        System.out.print("Enter the Price at the end of the Day: ");
        Name1.setCurrentStock(keyboard.nextDouble());
        System.out.printf("Percent Change for the Day: %.2f%%\n", Name1.calculate());
        System.out.println("");
        
        //Display Totals
        Name1.setPreviousStock(100.00);
        System.out.println("Value at the Start of the Week: $ " + Name1.getPreviousStock());
        System.out.println("Value at the End of the Week: $ " + Name1.getCurrentStock());
        System.out.printf("Percent Change for the Week: %.2f%%\n", Name1.calculate());
    }
}
