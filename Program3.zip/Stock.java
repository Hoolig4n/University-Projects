/* Charles Roberts
 * 140-001
 * Program 3
 * 3-26-2012
 * Program tracks a stock over the course of a week.
 */
package program3;


public class Stock {
    private double currentStock , previousStock; 
    private String symbol, name;
    
    //Calculate the % Changed
    public double calculate() {
    double percentChanged = (((currentStock - previousStock)/previousStock)*100);
        if (currentStock > previousStock) {
            
            return percentChanged;
        }
        else{
            
            return percentChanged;
        }
    }

    //Setters
   public void setName(String newName) {
       setEverything(this.currentStock, this.previousStock, this.symbol, newName);
   }
   public void setSymbol(String newSymbol) {
       setEverything(this.currentStock, this.previousStock, newSymbol, this.name);
   }

    public void setCurrentStock(double newCurrentStock) {
        setEverything(newCurrentStock, this.previousStock, this.symbol, this.name);
    }

    public void setPreviousStock(double newPreviousStock) {
        setEverything(this.currentStock, newPreviousStock, this.symbol, this.name);


    }
   
    //Designated Setter
    private void setEverything(double newCurrentStock, double newPreviousStock, String newName, String newSymbol) {
        if (newCurrentStock > 0.0) {
            currentStock = newCurrentStock;
        } 
        if (newPreviousStock > 0.0) {
            previousStock = newPreviousStock;
        }
        name = newName;
        symbol = newSymbol;
    }
    //Getters
    public double getCurrentStock() {
        return currentStock;
    }
    public String getName() {
        return name;
    }
    public double getPreviousStock() {
        return previousStock;
    }
    public String getSymbol() {
        return symbol;
    }
    


}
